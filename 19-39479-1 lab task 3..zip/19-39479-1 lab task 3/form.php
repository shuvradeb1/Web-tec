<!DOCTYPE html>
<html>
  <head>
    <title>Profile Picture</title>
</head>
<body>

<form action="upload.php" method="post" enctype="multipart/form-data">
  Select image to upload:
  <label>Profile Picture</label>
  <input type="file" name="fileToUpload" id="fileToUpload">
  <input type="submit" value="Upload Image" name="submit">
</form>

</body>
</html>